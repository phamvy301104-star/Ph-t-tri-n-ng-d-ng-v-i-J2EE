package com.example.Bai2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bai2Application {

	public static void main(String[] args) {
		SpringApplication.run(Bai2Application.class, args);
	}

}
