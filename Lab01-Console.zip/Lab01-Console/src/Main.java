import java.util.*;
import java.util.InputMismatchException;

public class Main {
    public static void main(String[] args) {
        List<Book> listBook = new ArrayList<>();
        Scanner x = new Scanner(System.in);
        String msg = """
                Chương trình quản lý sách
                1. Thêm 1 cuốn sách
                2. Xóa 1 cuốn sách
                3. Thay đổi cuốn sách
                4. Xuất thông tin tất cả các cuốn sách
                5. Tìm sách có từa để chữa chữ "Lập trình" và không phân biệt hoa thường
                6. Lấy sách: Nhập vào 1 số K và giá sách P muốn tìm kiếm. Hãy lấy tới da K cuốn sách để thỏa mãn có giá sách <= P
                7. Nhập vào 1 danh sách các tác giả từ bàn phím. Hãy cho biết tất cả cuốn sách của những tác giả này?
                0. Thoát
                Chọn chức năng:""";

        int chon = 0;
        do {
            System.out.print(msg);
            try {
                chon = x.nextInt();
            } catch (InputMismatchException e) {
                x.nextLine();
                System.out.println("Nhập không hợp lệ. Vui lòng nhập số nguyên.");
                continue;
            }
            switch (chon) {
                case 1 -> {
                    Book newBook = new Book();
                    newBook.input();
                    listBook.add(newBook);
                }
                case 2 -> {
                    System.out.print("Nhập vào mã sách cần xóa: ");
                    int bookId = x.nextInt();
                    // kiếm trò mã sách
                    try {
                        Book find = listBook.stream().filter(p -> p.getId() == bookId).findFirst().orElseThrow();
                        listBook.remove(find);
                        System.out.println("Đã xoá sách thành công");
                    } catch (NoSuchElementException e) {
                        System.out.println("Sách không tồn tại!");
                    }
                }
                case 3 -> {
                    System.out.print("Nhập vào mã sách cần điều chỉnh: ");
                    int bookId = x.nextInt();
                    try {
                        Book find = listBook.stream().filter(p -> p.getId() == bookId).findFirst().orElseThrow();
                        find.input();
                    } catch (NoSuchElementException e) {
                        System.out.println("Sách không tồn tại!");
                    }
                }
                case 4 -> {
                    System.out.println("\n xuất thông tin danh sách ");
                    listBook.forEach(p -> p.output());
                }
                case 5 -> {
                    List<Book> list5 = listBook.stream()
                            .filter(u -> u.getTitle().toLowerCase().contains("lập trình"))
                            .toList();
                    list5.forEach(Book::output);
                }
                case 6 -> {
                    System.out.print("Nhập K: ");
                    int k = x.nextInt();
                    System.out.print("Nhập giá P: ");
                    double p = x.nextDouble();
                    List<Book> list6 = listBook.stream()
                            .filter(u -> u.getPrice() <= p)
                            .limit(k)
                            .toList();
                    list6.forEach(Book::output);
                }
                case 7 -> {
                    x.nextLine(); // clear buffer
                    System.out.print("Nhập vào danh sách các tác giả (phân cách nhau bởi dấu phẩy): ");
                    String authorsInput = x.nextLine();
                    String[] authorsArray = authorsInput.split(",");
                    Set<String> authorsSet = new HashSet<>(Arrays.asList(authorsArray));
                    
                    List<Book> list7 = listBook.stream()
                            .filter(u -> authorsSet.contains(u.getAuthor().trim()))
                            .toList();
                    list7.forEach(Book::output);
                }
                case 0 -> System.out.println("Thoát chương trình");
                default -> System.out.println("Lựa chọn không hợp lệ");
            }
        } while (chon != 0);
    }
}
